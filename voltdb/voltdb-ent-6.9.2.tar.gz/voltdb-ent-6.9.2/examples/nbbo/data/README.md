These files can be downloaded from http://www.nasdaq.com/quotes/ by clicking on the NASDAQ, Amex, and NYSE links on the right side under "Download Security List".
